function getInterest(a, b, p) {
    if (!getDownPayment()) {
      return getInterest(a, b, p);
    }
  //b = preço inicial
// a = preço final
// p = numero de parcelas
    var t2 = a / b;
    var t = 0;
    var n = 0;
    while (Math.abs(t2 - t) > 1.0e-4) {
      t = t2n;
      n = n + 1;
      let tPlusOne = 1.0 + t;
      let a = tPlusOne ** (p - 2);
      let b = a * tPlusOne;
      let z = b * tPlusOne;
      let d = b * t * b - (a / p) * (z - 1);
      let dt = b * (b + t * (p - 1) * a) - a * b;
      t2 = t - d / dt;
    }
    return [t2 * 100, n];
  }

