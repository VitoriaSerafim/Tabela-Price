// Quando o formulário é enviado, atualize o valor das informações
$("#submitButton").on("click", function () {


    // Atualize o valor das informações com base nos valores do formulário
    $("#valorFinanciado").text("$" + $("#ipv").val());
    $("#valorVoltar").text("$" + $("#ipb").val());

    // Atualize o valor de "Meses a Voltar" na div1
    $("#mesesVoltar").text(mesesVoltar + " meses");


    var isChecked = $("#idp").is(":checked");
    $("#entrada").text(isChecked ? "true" : "false");
    $("#valorFinal").text("$" + $("#ipp").val());

    // Atualize o valor do parcelamento
    var parcelamento = $("#parc").val();
    $("#parcelamento").text(parcelamento + " meses");

    // Atualize a taxa de juros mensal na div
    var taxaMensal = parseFloat($("#itax").val());
    $("#taxaMensal").text(taxaMensal.toFixed(2));

    // Calcule a taxa de juros anual com base na taxa mensal
    var taxaAnual = (Math.pow(1 + taxaMensal / 100, 12) - 1) * 100;
    $("#taxaAnual").text(taxaAnual.toFixed(2));




    var np = parseInt($("#parc").val()); // Parcelamento (meses)
    var tax = parseFloat($("#itax").val()) / 100; // Taxa de juros (mensal)
    var pv = parseFloat($("#ipv").val()); // Valor financiado
    var pp = parseFloat($("#ipp").val()); // Valor final (opcional)
    var pb = parseFloat($("#ipb").val()); // Valor a voltar (opcional)

    var dp = $("#idp").is(":checked"); // Entrada (true ou false)



    // Validar os valores de entrada
    if (isNaN(np) || isNaN(tax) || isNaN(pv)) {
        $("#errorMessage").html("<p>Por favor, preencha os campos corretamente.</p>");
        $("#errorMessage").show();
        $("#successMessage").hide();
        return;
    }

    // Ajuste para a primeira parcela paga no ato da compra
    var n = np - (dp ? 1 : 0);

    // Calcular a parcela mensal (Tabela Price) com a entrada
    var i = tax; // Taxa de juros mensal
    var pmt; // Parcela mensal
    if (i === 0) {
        // Caso de juros zero
        pmt = pv / n;
    } else {
        pmt = (pv * i) / (1 - Math.pow(1 + i, -n));
    }

    // Calcular o valor final (se não fornecido)
    if (isNaN(pp)) {
        pp = pmt * n;
    }

    // Calcular o valor a voltar (se não fornecido)
    if (isNaN(pb)) {
        pb = pp - pv;
    }

    // Calcular o Custo Total do Empréstimo
    var cost = n * pmt - pv;

    // Calcular o Valor Total Pago
    var totalPaid = pv + cost;




    var saldoDevedor = pv;
    var valorCorrigido; // Variável para armazenar o valor corrigido


    // loop que itera as linhas da tabela
    for (var month = 1; month <= n; month++) {

        var juros = saldoDevedor * i;
        var amortizacao = pmt - juros;
        saldoDevedor -= amortizacao;
        console.log(juros)
        console.log(amortizacao)
        console.log(saldoDevedor)


        // Verifique se este é o mês a partir do final que corresponde a "Meses a Voltar"
        if (month == n - mesesVoltar) {
            console.log("@")
            valorCorrigido = saldoDevedor;
            console.log(valorCorrigido)
        }
    }









    // Calcule as informações da Div 2
    var valorFinanciado = parseFloat($("#ipv").val());
    var mesesVoltar = parseInt($("#mesesVoltar").val());
    var taxaMensal = parseFloat($("#itax").val());
    var interacoes = 12;
    var coeficienteFinanciamento = (i / (1 - Math.pow(1 + i, -n)));
    coeficienteFinanciamento = (i / (1 - Math.pow(1 + i, -n)));
    var valorPago = pmt * n;
    var taxaReal = ((Math.pow(coeficienteFinanciamento, 12 * mesesVoltar) - 1) * 100).toFixed(2);

    // Atualize as informações na Div 2
    $("#prestacao").text(pmt.toFixed(2));
    $("#coeficienteFinanciamento").text(coeficienteFinanciamento.toFixed(6));
    $("#valorPago").text(valorPago.toFixed(2));
    $("#interacoes").text(interacoes);
    $("#taxaReal").text(taxaReal);
    console.log("@")
    console.log(valorCorrigido)
    $("#valorCorrigido").text(totalPaid.toFixed(2));
    console.log(valorCorrigido)

});



